package pila;

/**
 *
 * Este objeto es una representacion abstracta de un tipo
 * de dato
 * @author GRUPO 3: Gonzalo Ortiz Jaureguizar, Alicia Perez Jimenez, Laura Reyero Sainz, Hector Sanjuan Redondo, Ruben Tarancon Garijo
 */
public abstract class Dato {
}
